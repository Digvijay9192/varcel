# Sales Dashboard

A small dashboard that shows monthly sales for **2022, 2023 and 2024**, built with **Next.js 15 (App Router), TypeScript, Tailwind CSS 4 and Recharts**. The code follows **atomic design**.

## What was built

- An empty `/dashboard` page, then the dashboard components added inside it (`/` redirects there).
- Mock sales data shaped like a Kaggle "Superstore Sales" dataset, aggregated by month for each year.
- Enhancements:
  - **Custom filter input:** type a minimum sales value to hide months below it.
  - **API integration:** data comes from `GET /api/sales?year=2024`. Set `NEXT_PUBLIC_SALES_API_URL` to use an external API instead.
  - **Multiple chart types:** bar, line and pie charts, switched with buttons.

> The data is mock data modelled on Kaggle-style sales. To use a real dataset, download a CSV from [kaggle.com](https://www.kaggle.com/), aggregate it by month and year, and replace `src/lib/data/sales.ts`.

## Atomic structure

```
src/
├── app/                     # Routes: /dashboard page, /api/sales route
├── components/
│   ├── atoms/               # Button, Input
│   ├── molecules/           # StatCard, YearTabs, ChartTypeToggle, ThresholdInput
│   ├── organisms/           # SalesChart, StatsGrid, SalesDashboard
│   └── templates/           # DashboardTemplate (page layout)
├── hooks/useSales.ts        # Fetches sales for a year
└── lib/                     # types, formatting, mock data
```

Atoms are single elements, molecules combine atoms, organisms are self-contained sections, templates lay out pages, and pages fill templates.

## Setup

Requires Node.js 18.18 or newer.

```bash
npm install
npm run dev      # http://localhost:3000
```

Other commands: `npm run build`, `npm start`, `npm run lint`.

### Use a real API (optional)

```bash
cp .env.example .env.local
# set NEXT_PUBLIC_SALES_API_URL, then restart the dev server
```

The API must answer `GET <url>?year=2024` with `{ "data": [{ "month": "Jan", "sales": 63100 }, ...] }`.
