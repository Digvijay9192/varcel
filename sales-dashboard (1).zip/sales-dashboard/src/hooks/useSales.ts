"use client";

import { useEffect, useState } from "react";
import type { MonthlySales, Year } from "@/lib/types";

export function useSales(year: Year) {
  const [data, setData] = useState<MonthlySales[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    const base = process.env.NEXT_PUBLIC_SALES_API_URL ?? "/api/sales";
    setLoading(true);
    setError(null);

    fetch(`${base}?year=${year}`, { signal: controller.signal })
      .then((res) => {
        if (!res.ok) throw new Error(`Request failed (${res.status})`);
        return res.json();
      })
      .then((json) => setData(json.data))
      .catch((err: Error) => {
        if (err.name !== "AbortError") setError(err.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, [year]);

  return { data, loading, error };
}
