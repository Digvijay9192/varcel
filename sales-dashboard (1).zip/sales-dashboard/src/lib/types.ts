export type Year = 2022 | 2023 | 2024;
export type ChartType = "bar" | "line" | "pie";

export interface MonthlySales {
  month: string;
  sales: number;
}
