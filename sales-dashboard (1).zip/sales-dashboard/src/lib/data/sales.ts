import type { MonthlySales, Year } from "@/lib/types";

/**
 * Mock data shaped like a Kaggle "Superstore Sales" dataset, aggregated by month.
 * Swap this for a real dataset or API (see README).
 */
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const RAW: Record<Year, number[]> = {
  2022: [48200, 52100, 61400, 58900, 63200, 67800, 64500, 70100, 76300, 81200, 92400, 108500],
  2023: [55300, 57800, 68900, 66200, 71500, 76400, 73900, 79800, 86100, 93700, 106200, 124800],
  2024: [63100, 66400, 77800, 75300, 82600, 88900, 85200, 92400, 99800, 108900, 123400, 142600],
};

export const YEARS: Year[] = [2024, 2023, 2022];

export function getSalesByYear(year: number): MonthlySales[] | null {
  const values = RAW[year as Year];
  if (!values) return null;
  return values.map((sales, i) => ({ month: MONTHS[i], sales }));
}
