import { StatCard } from "@/components/molecules/StatCard";
import { formatCurrency } from "@/lib/format";
import type { MonthlySales } from "@/lib/types";

export function StatsGrid({ data }: { data: MonthlySales[] }) {
  const total = data.reduce((sum, d) => sum + d.sales, 0);
  const best = data.reduce<MonthlySales | null>((b, d) => (!b || d.sales > b.sales ? d : b), null);

  return (
    <div className="grid gap-6 sm:grid-cols-3">
      <StatCard label="Total sales" value={formatCurrency(total)} />
      <StatCard label="Monthly average" value={formatCurrency(data.length ? total / data.length : 0)} />
      <StatCard label="Best month" value={best ? `${best.month}: ${formatCurrency(best.sales)}` : "None"} />
    </div>
  );
}
