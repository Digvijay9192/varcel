"use client";

import {
  Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart,
  Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { formatCurrency } from "@/lib/format";
import type { ChartType, MonthlySales } from "@/lib/types";

const COLORS = [
  "#0f766e", "#b45309", "#1d4ed8", "#be123c", "#4d7c0f", "#7e22ce",
  "#0e7490", "#a16207", "#3730a3", "#9f1239", "#3f6212", "#6b21a8",
];

const money = (v: unknown) => formatCurrency(Number(v));
const compact = (v: number) => `$${v / 1000}k`;

export function SalesChart({ data, type }: { data: MonthlySales[]; type: ChartType }) {
  if (data.length === 0) {
    return (
      <p className="py-24 text-center text-stone-500">
        No months reach this threshold. Lower the minimum to see more data.
      </p>
    );
  }

  return (
    <div className="h-96 w-full">
      <ResponsiveContainer>
        {type === "bar" ? (
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="month" />
            <YAxis tickFormatter={compact} />
            <Tooltip formatter={money} />
            <Bar dataKey="sales" fill="#0f766e" radius={[4, 4, 0, 0]} />
          </BarChart>
        ) : type === "line" ? (
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="month" />
            <YAxis tickFormatter={compact} />
            <Tooltip formatter={money} />
            <Line dataKey="sales" stroke="#0f766e" strokeWidth={3} dot={{ r: 4 }} />
          </LineChart>
        ) : (
          <PieChart>
            <Pie data={data} dataKey="sales" nameKey="month" outerRadius={140} label>
              {data.map((d, i) => (
                <Cell key={d.month} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip formatter={money} />
            <Legend />
          </PieChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
