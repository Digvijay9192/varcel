"use client";

import { useState } from "react";
import { ChartTypeToggle } from "@/components/molecules/ChartTypeToggle";
import { ThresholdInput } from "@/components/molecules/ThresholdInput";
import { YearTabs } from "@/components/molecules/YearTabs";
import { SalesChart } from "@/components/organisms/SalesChart";
import { StatsGrid } from "@/components/organisms/StatsGrid";
import { YEARS } from "@/lib/data/sales";
import { useSales } from "@/hooks/useSales";
import type { ChartType, Year } from "@/lib/types";

export function SalesDashboard() {
  const [year, setYear] = useState<Year>(2024);
  const [chartType, setChartType] = useState<ChartType>("bar");
  const [threshold, setThreshold] = useState("");
  const { data, loading, error } = useSales(year);

  const min = Number(threshold) || 0;
  const visible = data.filter((d) => d.sales >= min);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <YearTabs years={YEARS} value={year} onChange={setYear} />
        <ChartTypeToggle value={chartType} onChange={setChartType} />
      </div>

      <ThresholdInput value={threshold} onChange={setThreshold} />

      {error ? (
        <p role="alert" className="text-red-700">
          Could not load {year} sales: {error}. Reload the page to try again.
        </p>
      ) : loading ? (
        <p className="py-24 text-center text-stone-500">Loading {year} sales…</p>
      ) : (
        <>
          <StatsGrid data={visible} />
          <SalesChart data={visible} type={chartType} />
        </>
      )}
    </div>
  );
}
