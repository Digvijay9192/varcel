import type { ReactNode } from "react";

interface Props {
  title: string;
  description: string;
  children: ReactNode;
}

export function DashboardTemplate({ title, description, children }: Props) {
  return (
    <main className="mx-auto max-w-5xl px-6 py-12">
      <header className="mb-10">
        <h1 className="text-3xl font-semibold tracking-tight text-stone-900">{title}</h1>
        <p className="mt-2 max-w-prose text-stone-600">{description}</p>
      </header>
      {children}
    </main>
  );
}
