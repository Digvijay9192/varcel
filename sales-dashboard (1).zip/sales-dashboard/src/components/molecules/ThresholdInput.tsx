import { Input } from "@/components/atoms/Input";

interface Props {
  value: string;
  onChange: (value: string) => void;
}

export function ThresholdInput({ value, onChange }: Props) {
  return (
    <label className="flex items-center gap-2 text-sm text-stone-700">
      Show months with sales of at least
      <Input
        type="number"
        min={0}
        step={1000}
        inputMode="numeric"
        placeholder="e.g. 80000"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}
