import { Button } from "@/components/atoms/Button";
import type { Year } from "@/lib/types";

interface Props {
  years: Year[];
  value: Year;
  onChange: (year: Year) => void;
}

export function YearTabs({ years, value, onChange }: Props) {
  return (
    <div className="flex gap-2" role="group" aria-label="Year">
      {years.map((y) => (
        <Button key={y} active={y === value} onClick={() => onChange(y)}>
          {y}
        </Button>
      ))}
    </div>
  );
}
