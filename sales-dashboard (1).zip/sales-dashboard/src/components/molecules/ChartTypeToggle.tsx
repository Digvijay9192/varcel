import { Button } from "@/components/atoms/Button";
import type { ChartType } from "@/lib/types";

const OPTIONS: { value: ChartType; label: string }[] = [
  { value: "bar", label: "Bar" },
  { value: "line", label: "Line" },
  { value: "pie", label: "Pie" },
];

interface Props {
  value: ChartType;
  onChange: (type: ChartType) => void;
}

export function ChartTypeToggle({ value, onChange }: Props) {
  return (
    <div className="flex gap-2" role="group" aria-label="Chart type">
      {OPTIONS.map((o) => (
        <Button key={o.value} active={o.value === value} onClick={() => onChange(o.value)}>
          {o.label}
        </Button>
      ))}
    </div>
  );
}
