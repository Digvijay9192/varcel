import type { InputHTMLAttributes } from "react";

export function Input({ className = "", ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={`w-40 rounded-md bg-white px-3 py-1.5 text-sm text-stone-900 ring-1 ring-stone-300 placeholder:text-stone-400 focus-visible:outline-2 focus-visible:outline-teal-700 ${className}`}
      {...rest}
    />
  );
}
