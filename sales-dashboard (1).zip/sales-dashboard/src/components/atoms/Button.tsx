import type { ButtonHTMLAttributes } from "react";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean };

export function Button({ active = false, className = "", ...rest }: Props) {
  const tone = active
    ? "bg-teal-800 text-white"
    : "bg-white text-stone-700 ring-1 ring-stone-300 hover:bg-stone-100";
  return (
    <button
      type="button"
      aria-pressed={active}
      className={`rounded-md px-3.5 py-1.5 text-sm font-medium transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 ${tone} ${className}`}
      {...rest}
    />
  );
}
