import { NextRequest, NextResponse } from "next/server";
import { getSalesByYear } from "@/lib/data/sales";

export function GET(req: NextRequest) {
  const year = Number(req.nextUrl.searchParams.get("year"));
  const data = getSalesByYear(year);
  if (!data) {
    return NextResponse.json({ error: "Year not found" }, { status: 404 });
  }
  return NextResponse.json({ year, data });
}
