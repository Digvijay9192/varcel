import { DashboardTemplate } from "@/components/templates/DashboardTemplate";
import { SalesDashboard } from "@/components/organisms/SalesDashboard";

export const metadata = { title: "Sales dashboard" };

export default function DashboardPage() {
  return (
    <DashboardTemplate
      title="Sales by year"
      description="Monthly sales for 2022, 2023 and 2024. Switch the year or chart type, or set a minimum to hide weaker months."
    >
      <SalesDashboard />
    </DashboardTemplate>
  );
}
