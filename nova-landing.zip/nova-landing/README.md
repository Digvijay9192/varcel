# NOVA — Build Better. Work Smarter.

A fully responsive, modern landing page for **NOVA**, a fictional AI-powered
productivity platform that helps teams manage projects, automate repetitive
work, and collaborate without extra status meetings.

## Live Demo

> Deploy the `nova-landing` folder to Netlify, Vercel, or GitHub Pages (it's
> static — no build step) and paste the URL here before submitting.

`LIVE_DEMO_URL_HERE`

## Technologies Used

- **HTML5** — semantic markup (`<header>`, `<nav>`, `<main>`, `<section>`, `<footer>`)
- **CSS3** — custom properties (design tokens), CSS Grid & Flexbox, `clamp()` for fluid type, no framework/build step
- **Vanilla JavaScript (ES6)** — no dependencies, no bundler required
- **Google Fonts** — Fraunces (display) + Inter (body)

No framework was used on purpose (see *Technology choices* below) — the same
component boundaries map directly onto React components if the project needs
to grow into one (see *Converting to production*).

## Features

All 13 required sections are implemented: navigation, hero, trusted-by logos,
6 features, product/about, how it works, statistics, solutions/use cases,
3 testimonials, 3 pricing plans, 5 FAQ items, final CTA, and footer.

Required interactions:
- Responsive navigation with a working mobile hamburger menu
- Smooth scrolling to in-page anchors
- FAQ accordion (single-open, animated height, ARIA `aria-expanded`)
- Button and card hover effects
- All navigation links scroll to their target section

Bonus interactions implemented:
- Dark / light mode toggle (persisted via `localStorage`, respects OS preference on first visit)
- Animated statistics that count up when scrolled into view (`IntersectionObserver`)
- Testimonial carousel with dot navigation, arrows, and autoplay
- Monthly / annual pricing toggle (updates prices live, no page reload)
- "Get a demo" modal with a form and focus handling
- Newsletter email validation with inline error/success messaging
- Back-to-top button that appears after scrolling
- Active nav-link highlighting as you scroll (`IntersectionObserver`)

## Installation

No build tools required.

```bash
# 1. Clone or unzip the project
cd nova-landing

# 2. Open it directly
open index.html
# — or serve it locally so relative paths behave exactly like production:
npx serve .
# then visit the printed localhost URL
```

## Project Structure

```
nova-landing/
├── index.html        # all markup / all 13 sections
├── css/
│   └── styles.css    # design tokens, layout, responsive rules, dark mode
├── js/
│   └── script.js     # nav, theme, accordion, carousel, modal, validation
└── README.md
```

## Screenshots

> Add screenshots of desktop, tablet, and mobile views here before submitting,
> e.g.:
> `![Desktop hero](assets/screenshot-desktop.png)`
> `![Mobile menu](assets/screenshot-mobile.png)`

## AI Tools Used

Built with the assistance of **Claude** (Anthropic). Claude was used to:
- Draft the initial section structure and copy for the fictional NOVA brand
- Generate the base HTML/CSS/JS and the design token system
- Suggest the interaction patterns (accordion, carousel, modal) and their accessibility attributes

Every section was reviewed and adjusted afterward — see *Design decisions*
below for the reasoning behind the choices, and *Challenges* for what
needed hand-fixing after the initial generation.

---

## Short Explanation

### Design decisions
The brief's suggested brand (NOVA, an AI productivity platform) was used
as-is, but the visual identity was built specifically for it rather than
using a generic SaaS template: a deep indigo (`#1B1F3B`) paired with a warm
amber accent (`#F5A623`) instead of the more common near-black-plus-neon or
cream-plus-terracotta combinations, and a serif display face (Fraunces)
paired with a plain sans body face (Inter) so headlines feel intentional
rather than default. Feature cards use a left accent bar on hover instead of
a uniform drop-shadow "card kit" look, and the hero visual is a mocked task
board rather than a stock illustration, since the product's whole pitch is
about the board itself.

### Technology choices
Plain HTML/CSS/JS was chosen over React for this deliverable because the
page is a static marketing site with no dynamic data source — a build step
would add complexity without adding capability. All interactive pieces
(accordion, carousel, tabs, modal, toggle) are written as small, isolated
functions in `script.js` so they translate directly into components if the
project moves to React later.

### Component structure
Even without a framework, the HTML is organized the way components would
be: each `<section>` is self-contained with its own class namespace
(`.hero`, `.feature-card`, `.price-card`, `.faq-item`, etc.), so lifting any
section into a React component means copying one block of markup, one CSS
namespace, and one JS handler.

### Challenges faced
- Getting the FAQ accordion's open/close transition to animate smoothly
  required measuring `scrollHeight` in JS rather than relying on CSS alone,
  since `height: auto` can't be transitioned directly.
- Keeping the dark mode palette from just inverting the light palette (which
  tends to look muddy) meant tuning accent and card-background values
  separately for `[data-theme="dark"]` rather than reusing `filter: invert()`.
- Balancing the pricing cards so the "Most popular" plan stood out without
  making the other two look like afterthoughts took a couple of passes on
  border weight and shadow.

### How AI tools were used
See *AI Tools Used* above — Claude scaffolded the structure, styling system
and interactions; the copy, palette, and structure were reviewed and refined
manually rather than accepted as first-generated.

### Converting to production
To take this from a static site to a production application:
1. Move markup into components (React/Next.js), starting with the pieces
   that already have the clearest boundaries: `Hero`, `FeatureCard`,
   `PriceCard`, `FaqItem`, `TestimonialCarousel`.
2. Replace hard-coded content (features, pricing, testimonials, FAQ) with
   data fetched from a CMS or API, mapped over arrays instead of repeated markup.
3. Wire the demo-request and newsletter forms to real endpoints, with
   server-side validation to back up the client-side checks.
4. Add a build pipeline (Vite/Next.js) for bundling, minification, and
   image optimization, plus automated Lighthouse/accessibility checks in CI.
5. Introduce environment-based configuration for pricing and feature flags
   so plans can change without a code deploy.

### Accessibility improvements planned
Semantic landmarks, `aria-expanded`/`aria-selected`/`aria-live` attributes,
a skip link, and visible focus states are already in place. Next steps
would be a full screen-reader pass on the carousel and modal focus trap,
and running an automated audit (axe or Lighthouse) to catch contrast or
labeling issues before launch.

### Performance improvements planned
Fonts are loaded from Google Fonts CDN and could be self-hosted and
subset to cut render-blocking requests; images (once real screenshots
replace the CSS mockups) should be served as responsive `srcset` WebP;
and the JS could be split so above-the-fold interactions (nav, theme)
load before below-the-fold ones (carousel, modal).
