// ===================== Mobile hamburger menu =====================
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobile-menu');

function closeMobileMenu(){
  mobileMenu.classList.remove('open');
  hamburger.setAttribute('aria-expanded', 'false');
  hamburger.setAttribute('aria-label', 'Open menu');
}

hamburger.addEventListener('click', () => {
  const isOpen = mobileMenu.classList.toggle('open');
  hamburger.setAttribute('aria-expanded', String(isOpen));
  hamburger.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
});

// Close mobile menu after clicking a link (smooth scroll still applies via CSS)
mobileMenu.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', closeMobileMenu);
});

// ===================== Dark / light mode =====================
const themeToggle = document.getElementById('theme-toggle');
const root = document.documentElement;

function applyTheme(theme){
  if (theme === 'dark') {
    root.setAttribute('data-theme', 'dark');
    themeToggle.setAttribute('aria-pressed', 'true');
  } else {
    root.removeAttribute('data-theme');
    themeToggle.setAttribute('aria-pressed', 'false');
  }
}

const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
let savedTheme = null;
try { savedTheme = localStorage.getItem('nova-theme'); } catch (e) { /* storage unavailable */ }
applyTheme(savedTheme || (prefersDark ? 'dark' : 'light'));

themeToggle.addEventListener('click', () => {
  const isDark = root.getAttribute('data-theme') === 'dark';
  const next = isDark ? 'light' : 'dark';
  applyTheme(next);
  try { localStorage.setItem('nova-theme', next); } catch (e) { /* ignore */ }
});

// ===================== FAQ accordion =====================
document.querySelectorAll('.faq-question').forEach(btn => {
  btn.addEventListener('click', () => {
    const answer = btn.nextElementSibling;
    const isOpen = btn.getAttribute('aria-expanded') === 'true';

    // Close any other open item for a cleaner single-open accordion
    document.querySelectorAll('.faq-question[aria-expanded="true"]').forEach(other => {
      if (other !== btn) {
        other.setAttribute('aria-expanded', 'false');
        other.nextElementSibling.style.maxHeight = null;
      }
    });

    btn.setAttribute('aria-expanded', String(!isOpen));
    answer.style.maxHeight = isOpen ? null : answer.scrollHeight + 'px';
  });
});

// ===================== Solutions tabs =====================
const solutionTabs = document.querySelectorAll('.solution-tab');
solutionTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    solutionTabs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');

    document.querySelectorAll('.solution-panel').forEach(p => p.classList.remove('active'));
    document.querySelector(`.solution-panel[data-panel="${tab.dataset.tab}"]`).classList.add('active');
  });
});

// ===================== Testimonial carousel =====================
const track = document.getElementById('testimonial-track');
const slides = track.children.length;
const dotsWrap = document.getElementById('testimonial-dots');
let current = 0;
let autoplayTimer;

for (let i = 0; i < slides; i++) {
  const dot = document.createElement('button');
  dot.setAttribute('aria-label', `Go to testimonial ${i + 1}`);
  if (i === 0) dot.classList.add('active');
  dot.addEventListener('click', () => goToSlide(i));
  dotsWrap.appendChild(dot);
}

function goToSlide(index){
  current = (index + slides) % slides;
  track.style.transform = `translateX(-${current * 100}%)`;
  [...dotsWrap.children].forEach((d, i) => d.classList.toggle('active', i === current));
}

document.getElementById('testimonial-next').addEventListener('click', () => { goToSlide(current + 1); restartAutoplay(); });
document.getElementById('testimonial-prev').addEventListener('click', () => { goToSlide(current - 1); restartAutoplay(); });

function restartAutoplay(){
  clearInterval(autoplayTimer);
  autoplayTimer = setInterval(() => goToSlide(current + 1), 6000);
}
restartAutoplay();

// ===================== Pricing monthly / annual toggle =====================
const billingToggle = document.getElementById('billing-toggle');
billingToggle.addEventListener('click', () => {
  const isAnnual = billingToggle.getAttribute('aria-checked') === 'true';
  billingToggle.setAttribute('aria-checked', String(!isAnnual));

  document.querySelectorAll('.price-amount[data-monthly]').forEach(el => {
    const value = !isAnnual ? el.dataset.annual : el.dataset.monthly;
    el.textContent = '$' + value;
  });
});

// ===================== Animated statistics (on scroll into view) =====================
const statNumbers = document.querySelectorAll('.stat-number');
const statObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      animateStat(entry.target);
      statObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.5 });
statNumbers.forEach(el => statObserver.observe(el));

function animateStat(el){
  const target = parseFloat(el.dataset.target);
  const suffix = el.dataset.suffix || '';
  const isDecimal = target % 1 !== 0;
  const duration = 1400;
  const start = performance.now();

  function tick(now){
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const value = target * eased;
    el.textContent = (isDecimal ? value.toFixed(1) : Math.round(value)) + suffix;
    if (progress < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

// ===================== Back to top button =====================
const backToTop = document.getElementById('back-to-top');
window.addEventListener('scroll', () => {
  backToTop.classList.toggle('visible', window.scrollY > 600);
});
backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

// ===================== Demo modal =====================
const demoModal = document.getElementById('demo-modal');
const modalClose = document.getElementById('modal-close');
const demoForm = document.getElementById('demo-form');
const modalMsg = document.getElementById('modal-msg');

function openModal(){
  demoModal.classList.add('open');
  demoModal.setAttribute('aria-hidden', 'false');
  document.getElementById('demo-name').focus();
}
function closeModal(){
  demoModal.classList.remove('open');
  demoModal.setAttribute('aria-hidden', 'true');
  modalMsg.textContent = '';
  demoForm.reset();
}

['open-demo', 'open-demo-mobile', 'open-demo-hero', 'open-demo-final'].forEach(id => {
  const btn = document.getElementById(id);
  if (btn) btn.addEventListener('click', () => { closeMobileMenu(); openModal(); });
});
modalClose.addEventListener('click', closeModal);
demoModal.addEventListener('click', (e) => { if (e.target === demoModal) closeModal(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && demoModal.classList.contains('open')) closeModal(); });

demoForm.addEventListener('submit', (e) => {
  e.preventDefault();
  modalMsg.textContent = "Thanks — we'll reach out shortly to schedule your demo.";
  setTimeout(closeModal, 1800);
});

// ===================== Newsletter validation =====================
const newsletterForm = document.getElementById('newsletter-form');
const newsletterMsg = document.getElementById('newsletter-msg');

newsletterForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const input = document.getElementById('newsletter-email');
  const value = input.value.trim();
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!emailPattern.test(value)) {
    newsletterMsg.textContent = 'Please enter a valid email address.';
    newsletterMsg.style.color = '#E5625A';
    input.focus();
    return;
  }
  newsletterMsg.textContent = "You're subscribed. Welcome aboard!";
  newsletterMsg.style.color = '';
  newsletterForm.reset();
});

// ===================== Active nav link on scroll =====================
const sections = document.querySelectorAll('main section[id]');
const navLinks = document.querySelectorAll('.nav-links a');

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    const id = entry.target.getAttribute('id');
    const link = document.querySelector(`.nav-links a[href="#${id}"]`);
    if (!link) return;
    if (entry.isIntersecting) {
      navLinks.forEach(l => l.style.color = '');
      link.style.color = 'var(--ink)';
    }
  });
}, { rootMargin: '-40% 0px -50% 0px' });

sections.forEach(section => sectionObserver.observe(section));
